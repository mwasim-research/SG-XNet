# SG-XNet v2 - pilot summary

Target-run results: 3150. Metric: accuracy (micro-F1 for acmv9/citationv1/dblpv7), test set, epoch chosen on validation, mean ± std over splits.

## 0. Datasets

| dataset | group | nodes | edges | features | classes | edge homophily | adjusted homophily |
|---|---|---|---|---|---|---|---|
| cora | citation | 2708 | 5278 | 1433 | 7 | 0.810 | 0.771 |
| citeseer | citation | 3327 | 4552 | 3703 | 6 | 0.736 | 0.671 |
| pubmed | citation | 19717 | 44324 | 500 | 3 | 0.802 | 0.686 |
| dblp | citation | 17716 | 52867 | 1639 | 4 | 0.828 | 0.679 |
| acmv9 | aligned | 9360 | 15556 | 6775 | 5 | 0.892 | - |
| citationv1 | aligned | 8935 | 15098 | 6775 | 5 | 0.872 | - |
| dblpv7 | aligned | 5484 | 8117 | 6775 | 5 | 0.821 | - |
| roman_empire | heterophilic | 22662 | 32927 | 300 | 18 | 0.047 | -0.047 |
| amazon_ratings | heterophilic | 24492 | 93050 | 300 | 5 | 0.380 | 0.140 |
| chameleon_filtered | heterophilic | 890 | 8854 | 2325 | 5 | 0.236 | 0.030 |
| squirrel_filtered | heterophilic | 2223 | 46998 | 2089 | 5 | 0.207 | 0.009 |

## 1. From scratch (no transfer)

Label budget k = 1 per class

| target | GCN | GraphSAGE | GAT | GIN | MLP | SG-XNet |
|---|---|---|---|---|---|---|
| cora | **53.5 ± 7.6** | 47.2 ± 8.0 | 46.5 ± 10.0 | 49.2 ± 11.3 | 27.0 ± 3.6 | 47.3 ± 10.9 |
| pubmed | **60.1 ± 6.6** | 53.9 ± 6.1 | 56.7 ± 8.4 | 58.0 ± 6.9 | 50.6 ± 3.3 | 55.0 ± 3.6 |
| dblpv7 | 36.2 ± 8.5 | 34.4 ± 10.0 | 30.1 ± 9.9 | **36.7 ± 6.2** | 22.9 ± 6.7 | 31.6 ± 7.0 |
| citationv1 | **48.9 ± 6.7** | 31.6 ± 3.3 | 41.7 ± 7.5 | 42.8 ± 8.8 | 27.2 ± 0.9 | 42.5 ± 6.5 |
| acmv9 | 39.2 ± 2.5 | 34.5 ± 3.1 | 39.2 ± 5.0 | **39.5 ± 5.5** | 28.0 ± 3.2 | 37.0 ± 6.8 |
| chameleon_filtered | 34.8 ± 2.0 | **35.8 ± 2.6** | 35.8 ± 1.7 | 33.4 ± 3.1 | 28.3 ± 9.3 | 35.1 ± 2.5 |
| roman_empire | 14.3 ± 2.1 | 19.2 ± 4.5 | 14.3 ± 1.0 | 14.3 ± 1.5 | **28.2 ± 3.8** | 14.2 ± 2.1 |

Label budget k = 5 per class

| target | GCN | GraphSAGE | GAT | GIN | MLP | SG-XNet |
|---|---|---|---|---|---|---|
| cora | 69.4 ± 4.1 | 65.8 ± 6.3 | **71.0 ± 3.0** | 70.0 ± 1.9 | 38.5 ± 4.4 | 69.3 ± 3.5 |
| pubmed | **70.0 ± 6.9** | 67.0 ± 4.5 | 67.8 ± 4.7 | 66.1 ± 3.6 | 59.7 ± 2.3 | 66.2 ± 5.0 |
| dblpv7 | **58.4 ± 4.0** | 47.3 ± 5.6 | 52.7 ± 3.7 | 51.6 ± 6.2 | 26.9 ± 2.7 | 53.4 ± 3.0 |
| citationv1 | **65.6 ± 3.9** | 54.5 ± 2.8 | 61.5 ± 4.9 | 61.3 ± 5.0 | 30.7 ± 1.8 | 60.0 ± 5.1 |
| acmv9 | 52.2 ± 4.4 | 45.1 ± 2.8 | 51.8 ± 5.6 | **54.9 ± 5.5** | 31.4 ± 3.0 | 51.2 ± 2.9 |
| chameleon_filtered | **36.2 ± 1.6** | 34.2 ± 3.2 | 35.2 ± 2.2 | 35.0 ± 1.8 | 35.2 ± 1.5 | 35.9 ± 1.8 |
| roman_empire | 24.1 ± 2.0 | **44.2 ± 3.6** | 20.1 ± 2.8 | 25.9 ± 4.0 | 38.3 ± 2.0 | 23.3 ± 2.9 |

Label budget k = 20 per class

| target | GCN | GraphSAGE | GAT | GIN | MLP | SG-XNet |
|---|---|---|---|---|---|---|
| cora | 78.3 ± 3.1 | 76.9 ± 1.9 | 78.0 ± 2.9 | 77.9 ± 1.3 | 55.6 ± 3.0 | **79.1 ± 1.5** |
| pubmed | 74.6 ± 2.6 | 74.5 ± 2.1 | **75.9 ± 1.1** | 74.4 ± 2.1 | 68.4 ± 1.7 | 74.0 ± 1.7 |
| dblpv7 | **70.0 ± 1.9** | 61.9 ± 3.6 | 66.7 ± 1.6 | 67.4 ± 2.2 | 40.6 ± 3.3 | 65.7 ± 1.9 |
| citationv1 | 74.6 ± 2.4 | 69.4 ± 4.0 | 71.9 ± 1.7 | 71.7 ± 2.8 | 35.3 ± 3.0 | **74.8 ± 1.6** |
| acmv9 | **67.3 ± 1.2** | 60.6 ± 4.6 | 65.7 ± 2.9 | 64.2 ± 2.9 | 39.0 ± 3.3 | 63.1 ± 3.2 |
| chameleon_filtered | 36.7 ± 2.7 | 37.0 ± 3.3 | 37.0 ± 0.6 | 36.8 ± 2.4 | **38.5 ± 2.7** | 38.3 ± 1.7 |
| roman_empire | 30.3 ± 0.7 | **57.6 ± 1.1** | 25.2 ± 2.4 | 44.2 ± 2.2 | 46.7 ± 1.5 | 31.6 ± 1.0 |

## 2. Transfer gain = condition - scratch (percentage points, paired by split)

Cell: mean difference (* = paired t-test, Holm-adjusted within each condition and model, p < 0.05) (splits where the condition beat scratch / splits). Full statistics, including Wilcoxon p-values: transfer_gains_pilot.csv.

| pair | model | k | scratch | finetune | frozen | zeroshot |
|---|---|---|---|---|---|---|
| citeseer→cora | GCN | 1 | 53.5 ± 7.6 | -3.7 (0/5) | -6.3 (0/5) | - |
| citeseer→cora | GCN | 5 | 69.4 ± 4.1 | -0.7 (3/5) | -0.8 (2/5) | - |
| citeseer→cora | GCN | 20 | 78.3 ± 3.1 | -0.7 (1/5) | -0.2 (4/5) | - |
| citeseer→cora | GraphSAGE | 1 | 47.2 ± 8.0 | -6.3 (2/5) | -10.9 (2/5) | - |
| citeseer→cora | GraphSAGE | 5 | 65.8 ± 6.3 | -7.1 (1/5) | -12.0 (1/5) | - |
| citeseer→cora | GraphSAGE | 20 | 76.9 ± 1.9 | -1.9 (1/5) | -9.9 (0/5) | - |
| citeseer→cora | GAT | 1 | 46.5 ± 10.0 | +2.8 (4/5) | +1.4 (3/5) | - |
| citeseer→cora | GAT | 5 | 71.0 ± 3.0 | -3.2 (0/5) | -3.3* (0/5) | - |
| citeseer→cora | GAT | 20 | 78.0 ± 2.9 | +0.3 (2/5) | -2.6 (0/5) | - |
| citeseer→cora | GIN | 1 | 49.2 ± 11.3 | -6.3 (1/5) | -11.1 (1/5) | - |
| citeseer→cora | GIN | 5 | 70.0 ± 1.9 | -5.5 (0/5) | -7.2 (0/5) | - |
| citeseer→cora | GIN | 20 | 77.9 ± 1.3 | -3.3 (0/5) | -5.9 (1/5) | - |
| citeseer→cora | MLP | 1 | 27.0 ± 3.6 | +1.2 (4/5) | -0.3 (4/5) | - |
| citeseer→cora | MLP | 5 | 38.5 ± 4.4 | -1.1 (2/5) | -4.1 (1/5) | - |
| citeseer→cora | MLP | 20 | 55.6 ± 3.0 | -1.3 (2/5) | -6.4 (0/5) | - |
| citeseer→cora | SG-XNet | 1 | 47.3 ± 10.9 | -0.0 (2/5) | -4.4 (2/5) | - |
| citeseer→cora | SG-XNet | 5 | 69.3 ± 3.5 | -3.7 (0/5) | -6.6 (1/5) | - |
| citeseer→cora | SG-XNet | 20 | 79.1 ± 1.5 | -3.5 (0/5) | -2.6 (0/5) | - |
| dblp→pubmed | GCN | 1 | 60.1 ± 6.6 | -0.5 (2/5) | -1.1 (2/5) | - |
| dblp→pubmed | GCN | 5 | 70.0 ± 6.9 | -1.9 (0/5) | -0.1 (2/5) | - |
| dblp→pubmed | GCN | 20 | 74.6 ± 2.6 | +2.4 (5/5) | +1.6 (5/5) | - |
| dblp→pubmed | GraphSAGE | 1 | 53.9 ± 6.1 | +2.1 (4/5) | +3.9 (5/5) | - |
| dblp→pubmed | GraphSAGE | 5 | 67.0 ± 4.5 | +0.1 (3/5) | -1.6 (1/5) | - |
| dblp→pubmed | GraphSAGE | 20 | 74.5 ± 2.1 | -1.3 (1/5) | -0.5 (2/5) | - |
| dblp→pubmed | GAT | 1 | 56.7 ± 8.4 | +0.2 (4/5) | +0.4 (3/5) | - |
| dblp→pubmed | GAT | 5 | 67.8 ± 4.7 | -2.0 (1/5) | +0.1 (2/5) | - |
| dblp→pubmed | GAT | 20 | 75.9 ± 1.1 | +0.0 (2/5) | -0.7 (1/5) | - |
| dblp→pubmed | GIN | 1 | 58.0 ± 6.9 | -1.5 (1/5) | -1.9 (1/5) | - |
| dblp→pubmed | GIN | 5 | 66.1 ± 3.6 | +1.0 (4/5) | +2.3 (5/5) | - |
| dblp→pubmed | GIN | 20 | 74.4 ± 2.1 | +1.6 (5/5) | +1.4 (3/5) | - |
| dblp→pubmed | MLP | 1 | 50.6 ± 3.3 | -0.5 (2/5) | +0.5 (3/5) | - |
| dblp→pubmed | MLP | 5 | 59.7 ± 2.3 | +0.1 (2/5) | +0.9 (2/5) | - |
| dblp→pubmed | MLP | 20 | 68.4 ± 1.7 | -1.3 (2/5) | -0.8 (1/5) | - |
| dblp→pubmed | SG-XNet | 1 | 55.0 ± 3.6 | -0.9 (1/5) | +1.0 (2/5) | - |
| dblp→pubmed | SG-XNet | 5 | 66.2 ± 5.0 | -0.9 (1/5) | -3.0 (1/5) | - |
| dblp→pubmed | SG-XNet | 20 | 74.0 ± 1.7 | +0.5 (3/5) | -0.2 (2/5) | - |
| acmv9→dblpv7 | GCN | 1 | 36.2 ± 8.5 | +33.1* (5/5) | +36.3* (5/5) | +35.0* (5/5) |
| acmv9→dblpv7 | GCN | 5 | 58.4 ± 4.0 | +10.5 (5/5) | +15.3* (5/5) | +12.8* (5/5) |
| acmv9→dblpv7 | GCN | 20 | 70.0 ± 1.9 | +2.0 (5/5) | +3.7 (5/5) | +1.2 (3/5) |
| acmv9→dblpv7 | GraphSAGE | 1 | 34.4 ± 10.0 | +26.4 (5/5) | +35.5* (5/5) | +35.3* (5/5) |
| acmv9→dblpv7 | GraphSAGE | 5 | 47.3 ± 5.6 | +17.8 (5/5) | +23.1* (5/5) | +22.3* (5/5) |
| acmv9→dblpv7 | GraphSAGE | 20 | 61.9 ± 3.6 | +8.8 (5/5) | +10.2 (5/5) | +7.7* (5/5) |
| acmv9→dblpv7 | GAT | 1 | 30.1 ± 9.9 | +23.7 (5/5) | +23.0 (5/5) | +24.9* (5/5) |
| acmv9→dblpv7 | GAT | 5 | 52.7 ± 3.7 | +3.4 (3/5) | +3.4 (3/5) | +2.4 (3/5) |
| acmv9→dblpv7 | GAT | 20 | 66.7 ± 1.6 | -3.6 (0/5) | -16.0 (0/5) | -11.5* (0/5) |
| acmv9→dblpv7 | GIN | 1 | 36.7 ± 6.2 | +30.7* (5/5) | +29.5* (5/5) | +29.7* (5/5) |
| acmv9→dblpv7 | GIN | 5 | 51.6 ± 6.2 | +14.8 (5/5) | +15.6 (5/5) | +14.8* (5/5) |
| acmv9→dblpv7 | GIN | 20 | 67.4 ± 2.2 | -0.3 (3/5) | +1.6 (4/5) | -1.0 (2/5) |
| acmv9→dblpv7 | MLP | 1 | 22.9 ± 6.7 | +32.0* (5/5) | +32.0* (5/5) | +34.1* (5/5) |
| acmv9→dblpv7 | MLP | 5 | 26.9 ± 2.7 | +28.6* (5/5) | +29.0* (5/5) | +30.1* (5/5) |
| acmv9→dblpv7 | MLP | 20 | 40.6 ± 3.3 | +15.6* (5/5) | +15.7* (5/5) | +16.4* (5/5) |
| acmv9→dblpv7 | SG-XNet | 1 | 31.6 ± 7.0 | +35.5* (5/5) | +39.0* (5/5) | +38.2* (5/5) |
| acmv9→dblpv7 | SG-XNet | 5 | 53.4 ± 3.0 | +17.0* (5/5) | +16.7* (5/5) | +16.4* (5/5) |
| acmv9→dblpv7 | SG-XNet | 20 | 65.7 ± 1.9 | +6.0 (5/5) | +6.0* (5/5) | +4.1* (5/5) |
| acmv9→citationv1 | GCN | 1 | 48.9 ± 6.7 | +19.3* (5/5) | +28.9* (5/5) | +28.5* (5/5) |
| acmv9→citationv1 | GCN | 5 | 65.6 ± 3.9 | +9.5* (5/5) | +12.1* (5/5) | +11.8* (5/5) |
| acmv9→citationv1 | GCN | 20 | 74.6 ± 2.4 | +3.4 (5/5) | +4.0 (5/5) | +2.8 (5/5) |
| acmv9→citationv1 | GraphSAGE | 1 | 31.6 ± 3.3 | +20.0 (5/5) | +33.7* (5/5) | +29.9* (5/5) |
| acmv9→citationv1 | GraphSAGE | 5 | 54.5 ± 2.8 | +6.0 (4/5) | +14.8* (5/5) | +7.1 (5/5) |
| acmv9→citationv1 | GraphSAGE | 20 | 69.4 ± 4.0 | +1.9 (4/5) | +1.5 (3/5) | -7.8 (0/5) |
| acmv9→citationv1 | GAT | 1 | 41.7 ± 7.5 | +24.3 (5/5) | +30.4* (5/5) | +31.3* (5/5) |
| acmv9→citationv1 | GAT | 5 | 61.5 ± 4.9 | +9.2 (5/5) | +12.2 (5/5) | +11.7 (5/5) |
| acmv9→citationv1 | GAT | 20 | 71.9 ± 1.7 | -1.5 (2/5) | +2.2 (4/5) | +1.3 (4/5) |
| acmv9→citationv1 | GIN | 1 | 42.8 ± 8.8 | +18.0 (4/5) | +29.0* (5/5) | +30.0* (5/5) |
| acmv9→citationv1 | GIN | 5 | 61.3 ± 5.0 | +7.5 (4/5) | +13.4 (5/5) | +11.5 (5/5) |
| acmv9→citationv1 | GIN | 20 | 71.7 ± 2.8 | +1.9 (3/5) | +3.3 (5/5) | +1.1 (3/5) |
| acmv9→citationv1 | MLP | 1 | 27.2 ± 0.9 | +27.3* (5/5) | +24.7* (5/5) | +26.7* (5/5) |
| acmv9→citationv1 | MLP | 5 | 30.7 ± 1.8 | +23.1* (5/5) | +22.8* (5/5) | +23.2* (5/5) |
| acmv9→citationv1 | MLP | 20 | 35.3 ± 3.0 | +18.2* (5/5) | +17.6* (5/5) | +18.7* (5/5) |
| acmv9→citationv1 | SG-XNet | 1 | 42.5 ± 6.5 | +30.8* (5/5) | +31.5* (5/5) | +30.9* (5/5) |
| acmv9→citationv1 | SG-XNet | 5 | 60.0 ± 5.1 | +15.0* (5/5) | +15.4 (5/5) | +13.5 (5/5) |
| acmv9→citationv1 | SG-XNet | 20 | 74.8 ± 1.6 | +2.6 (5/5) | +0.8 (3/5) | -1.3 (3/5) |
| citationv1→acmv9 | GCN | 1 | 39.2 ± 2.5 | +28.3* (5/5) | +31.0* (5/5) | +30.0* (5/5) |
| citationv1→acmv9 | GCN | 5 | 52.2 ± 4.4 | +14.0* (5/5) | +17.4* (5/5) | +17.0* (5/5) |
| citationv1→acmv9 | GCN | 20 | 67.3 ± 1.2 | -2.2 (1/5) | +3.6 (5/5) | +2.0 (4/5) |
| citationv1→acmv9 | GraphSAGE | 1 | 34.5 ± 3.1 | +29.0* (5/5) | +36.4* (5/5) | +35.6* (5/5) |
| citationv1→acmv9 | GraphSAGE | 5 | 45.1 ± 2.8 | +19.4 (5/5) | +25.0* (5/5) | +25.1* (5/5) |
| citationv1→acmv9 | GraphSAGE | 20 | 60.6 ± 4.6 | +8.6 (5/5) | +11.2 (5/5) | +9.6 (5/5) |
| citationv1→acmv9 | GAT | 1 | 39.2 ± 5.0 | +25.1 (5/5) | +30.1* (5/5) | +29.7* (5/5) |
| citationv1→acmv9 | GAT | 5 | 51.8 ± 5.6 | +14.3 (5/5) | +18.1 (5/5) | +17.2* (5/5) |
| citationv1→acmv9 | GAT | 20 | 65.7 ± 2.9 | -0.9 (3/5) | +4.6 (5/5) | +3.4 (4/5) |
| citationv1→acmv9 | GIN | 1 | 39.5 ± 5.5 | +15.8 (4/5) | +30.3* (5/5) | +31.3* (5/5) |
| citationv1→acmv9 | GIN | 5 | 54.9 ± 5.5 | +5.6 (4/5) | +16.9* (5/5) | +15.9* (5/5) |
| citationv1→acmv9 | GIN | 20 | 64.2 ± 2.9 | +6.5 (5/5) | +6.8 (5/5) | +6.7 (5/5) |
| citationv1→acmv9 | MLP | 1 | 28.0 ± 3.2 | +27.2* (5/5) | +26.2* (5/5) | +27.7* (5/5) |
| citationv1→acmv9 | MLP | 5 | 31.4 ± 3.0 | +24.6* (5/5) | +23.2* (5/5) | +24.2* (5/5) |
| citationv1→acmv9 | MLP | 20 | 39.0 ± 3.3 | +16.6* (5/5) | +15.3* (5/5) | +16.7* (5/5) |
| citationv1→acmv9 | SG-XNet | 1 | 37.0 ± 6.8 | +31.1* (5/5) | +31.4* (5/5) | +31.6* (5/5) |
| citationv1→acmv9 | SG-XNet | 5 | 51.2 ± 2.9 | +17.6* (5/5) | +18.7* (5/5) | +17.4* (5/5) |
| citationv1→acmv9 | SG-XNet | 20 | 63.1 ± 3.2 | +8.7* (5/5) | +8.4* (5/5) | +5.6* (5/5) |
| citationv1→dblpv7 | GCN | 1 | 36.2 ± 8.5 | +35.5* (5/5) | +39.3* (5/5) | +38.9* (5/5) |
| citationv1→dblpv7 | GCN | 5 | 58.4 ± 4.0 | +13.4* (5/5) | +17.3* (5/5) | +16.7* (5/5) |
| citationv1→dblpv7 | GCN | 20 | 70.0 ± 1.9 | +3.9 (5/5) | +6.4* (5/5) | +5.0* (5/5) |
| citationv1→dblpv7 | GraphSAGE | 1 | 34.4 ± 10.0 | +25.2 (5/5) | +35.6* (5/5) | +37.0* (5/5) |
| citationv1→dblpv7 | GraphSAGE | 5 | 47.3 ± 5.6 | +16.5 (5/5) | +23.3* (5/5) | +24.0* (5/5) |
| citationv1→dblpv7 | GraphSAGE | 20 | 61.9 ± 3.6 | +8.4 (5/5) | +10.2 (5/5) | +9.4* (5/5) |
| citationv1→dblpv7 | GAT | 1 | 30.1 ± 9.9 | +36.3* (5/5) | +36.2* (5/5) | +38.1* (5/5) |
| citationv1→dblpv7 | GAT | 5 | 52.7 ± 3.7 | +12.5 (4/5) | +13.6 (5/5) | +15.6 (5/5) |
| citationv1→dblpv7 | GAT | 20 | 66.7 ± 1.6 | -4.8 (0/5) | -0.1 (4/5) | +1.7 (4/5) |
| citationv1→dblpv7 | GIN | 1 | 36.7 ± 6.2 | +33.0* (5/5) | +35.7* (5/5) | +35.1* (5/5) |
| citationv1→dblpv7 | GIN | 5 | 51.6 ± 6.2 | +17.9 (5/5) | +18.7* (5/5) | +20.3* (5/5) |
| citationv1→dblpv7 | GIN | 20 | 67.4 ± 2.2 | +4.9 (4/5) | +2.8 (4/5) | +4.5 (5/5) |
| citationv1→dblpv7 | MLP | 1 | 22.9 ± 6.7 | +34.8* (5/5) | +34.2* (5/5) | +35.5* (5/5) |
| citationv1→dblpv7 | MLP | 5 | 26.9 ± 2.7 | +29.7* (5/5) | +30.0* (5/5) | +31.4* (5/5) |
| citationv1→dblpv7 | MLP | 20 | 40.6 ± 3.3 | +16.0* (5/5) | +16.3* (5/5) | +17.7* (5/5) |
| citationv1→dblpv7 | SG-XNet | 1 | 31.6 ± 7.0 | +38.3* (5/5) | +39.6* (5/5) | +40.1* (5/5) |
| citationv1→dblpv7 | SG-XNet | 5 | 53.4 ± 3.0 | +16.0* (5/5) | +16.8* (5/5) | +18.4* (5/5) |
| citationv1→dblpv7 | SG-XNet | 20 | 65.7 ± 1.9 | +7.6 (5/5) | +5.8 (5/5) | +6.0* (5/5) |
| dblpv7→acmv9 | GCN | 1 | 39.2 ± 2.5 | +25.0* (5/5) | +27.4* (5/5) | +26.8* (5/5) |
| dblpv7→acmv9 | GCN | 5 | 52.2 ± 4.4 | +9.8 (4/5) | +15.1 (5/5) | +13.8* (5/5) |
| dblpv7→acmv9 | GCN | 20 | 67.3 ± 1.2 | +0.9 (4/5) | +0.8 (4/5) | -1.2 (1/5) |
| dblpv7→acmv9 | GraphSAGE | 1 | 34.5 ± 3.1 | +20.4* (5/5) | +31.8* (5/5) | +31.4* (5/5) |
| dblpv7→acmv9 | GraphSAGE | 5 | 45.1 ± 2.8 | +13.2 (5/5) | +19.7* (5/5) | +20.8* (5/5) |
| dblpv7→acmv9 | GraphSAGE | 20 | 60.6 ± 4.6 | +6.6 (5/5) | +8.1 (5/5) | +5.4 (5/5) |
| dblpv7→acmv9 | GAT | 1 | 39.2 ± 5.0 | +24.6* (5/5) | +26.5* (5/5) | +25.1* (5/5) |
| dblpv7→acmv9 | GAT | 5 | 51.8 ± 5.6 | +9.7 (4/5) | +13.9 (5/5) | +12.5* (5/5) |
| dblpv7→acmv9 | GAT | 20 | 65.7 ± 2.9 | -0.0 (3/5) | +2.1 (3/5) | -1.3 (1/5) |
| dblpv7→acmv9 | GIN | 1 | 39.5 ± 5.5 | +20.3 (5/5) | +25.3* (5/5) | +25.3* (5/5) |
| dblpv7→acmv9 | GIN | 5 | 54.9 ± 5.5 | +8.0 (4/5) | +10.5 (5/5) | +9.9 (5/5) |
| dblpv7→acmv9 | GIN | 20 | 64.2 ± 2.9 | +1.8 (4/5) | +3.8 (4/5) | +0.7 (3/5) |
| dblpv7→acmv9 | MLP | 1 | 28.0 ± 3.2 | +25.0* (5/5) | +24.6* (5/5) | +25.0* (5/5) |
| dblpv7→acmv9 | MLP | 5 | 31.4 ± 3.0 | +21.8* (5/5) | +17.5* (5/5) | +21.6* (5/5) |
| dblpv7→acmv9 | MLP | 20 | 39.0 ± 3.3 | +13.1 (5/5) | +11.2* (5/5) | +14.1* (5/5) |
| dblpv7→acmv9 | SG-XNet | 1 | 37.0 ± 6.8 | +28.9* (5/5) | +28.5* (5/5) | +28.2* (5/5) |
| dblpv7→acmv9 | SG-XNet | 5 | 51.2 ± 2.9 | +13.9* (5/5) | +15.6* (5/5) | +14.0* (5/5) |
| dblpv7→acmv9 | SG-XNet | 20 | 63.1 ± 3.2 | +6.5 (5/5) | +5.8 (5/5) | +2.2 (3/5) |
| dblpv7→citationv1 | GCN | 1 | 48.9 ± 6.7 | +12.3 (5/5) | +27.1* (5/5) | +27.3* (5/5) |
| dblpv7→citationv1 | GCN | 5 | 65.6 ± 3.9 | +7.6 (5/5) | +10.4 (5/5) | +10.6* (5/5) |
| dblpv7→citationv1 | GCN | 20 | 74.6 ± 2.4 | +2.5 (5/5) | +2.4 (4/5) | +1.6 (3/5) |
| dblpv7→citationv1 | GraphSAGE | 1 | 31.6 ± 3.3 | +15.2 (5/5) | +34.2* (5/5) | +33.2* (5/5) |
| dblpv7→citationv1 | GraphSAGE | 5 | 54.5 ± 2.8 | +7.4 (4/5) | +14.0* (5/5) | +10.4* (5/5) |
| dblpv7→citationv1 | GraphSAGE | 20 | 69.4 ± 4.0 | +2.0 (4/5) | +1.4 (3/5) | -4.4 (2/5) |
| dblpv7→citationv1 | GAT | 1 | 41.7 ± 7.5 | +24.8 (5/5) | +29.7* (5/5) | +29.6* (5/5) |
| dblpv7→citationv1 | GAT | 5 | 61.5 ± 4.9 | +8.9 (5/5) | +9.9 (5/5) | +9.9* (5/5) |
| dblpv7→citationv1 | GAT | 20 | 71.9 ± 1.7 | -1.8 (1/5) | +1.3 (4/5) | -0.4 (2/5) |
| dblpv7→citationv1 | GIN | 1 | 42.8 ± 8.8 | +18.5 (5/5) | +28.1* (5/5) | +28.8* (5/5) |
| dblpv7→citationv1 | GIN | 5 | 61.3 ± 5.0 | +8.9 (5/5) | +9.9 (5/5) | +10.3 (5/5) |
| dblpv7→citationv1 | GIN | 20 | 71.7 ± 2.8 | +2.3 (4/5) | +1.3 (4/5) | -0.1 (3/5) |
| dblpv7→citationv1 | MLP | 1 | 27.2 ± 0.9 | +24.8* (5/5) | +22.1* (5/5) | +25.1* (5/5) |
| dblpv7→citationv1 | MLP | 5 | 30.7 ± 1.8 | +21.4* (5/5) | +20.0* (5/5) | +21.7* (5/5) |
| dblpv7→citationv1 | MLP | 20 | 35.3 ± 3.0 | +16.6* (5/5) | +17.4* (5/5) | +17.1* (5/5) |
| dblpv7→citationv1 | SG-XNet | 1 | 42.5 ± 6.5 | +32.2* (5/5) | +31.0* (5/5) | +30.6* (5/5) |
| dblpv7→citationv1 | SG-XNet | 5 | 60.0 ± 5.1 | +13.0 (5/5) | +14.0 (5/5) | +13.1 (5/5) |
| dblpv7→citationv1 | SG-XNet | 20 | 74.8 ± 1.6 | +2.3 (5/5) | +1.0 (4/5) | -1.6 (2/5) |
| squirrel_filtered→chameleon_filtered | GCN | 1 | 34.8 ± 2.0 | +1.0 (4/5) | +0.3 (3/5) | - |
| squirrel_filtered→chameleon_filtered | GCN | 5 | 36.2 ± 1.6 | -0.6 (1/5) | -2.1 (0/5) | - |
| squirrel_filtered→chameleon_filtered | GCN | 20 | 36.7 ± 2.7 | +1.2 (4/5) | +0.4 (4/5) | - |
| squirrel_filtered→chameleon_filtered | GraphSAGE | 1 | 35.8 ± 2.6 | -3.2 (1/5) | -3.3 (0/5) | - |
| squirrel_filtered→chameleon_filtered | GraphSAGE | 5 | 34.2 ± 3.2 | -1.0 (2/5) | -0.3 (2/5) | - |
| squirrel_filtered→chameleon_filtered | GraphSAGE | 20 | 37.0 ± 3.3 | +0.9 (4/5) | -1.4 (3/5) | - |
| squirrel_filtered→chameleon_filtered | GAT | 1 | 35.8 ± 1.7 | -1.0 (2/5) | -6.1 (0/5) | - |
| squirrel_filtered→chameleon_filtered | GAT | 5 | 35.2 ± 2.2 | -0.6 (1/5) | -0.7 (2/5) | - |
| squirrel_filtered→chameleon_filtered | GAT | 20 | 37.0 ± 0.6 | -1.2 (1/5) | -2.4 (0/5) | - |
| squirrel_filtered→chameleon_filtered | GIN | 1 | 33.4 ± 3.1 | +0.2 (3/5) | +0.1 (3/5) | - |
| squirrel_filtered→chameleon_filtered | GIN | 5 | 35.0 ± 1.8 | -0.3 (1/5) | -1.0 (2/5) | - |
| squirrel_filtered→chameleon_filtered | GIN | 20 | 36.8 ± 2.4 | +1.6 (4/5) | +1.2 (3/5) | - |
| squirrel_filtered→chameleon_filtered | MLP | 1 | 28.3 ± 9.3 | +5.4 (3/5) | +0.7 (2/5) | - |
| squirrel_filtered→chameleon_filtered | MLP | 5 | 35.2 ± 1.5 | -0.5 (1/5) | -2.5 (1/5) | - |
| squirrel_filtered→chameleon_filtered | MLP | 20 | 38.5 ± 2.7 | -2.3 (1/5) | -2.3 (1/5) | - |
| squirrel_filtered→chameleon_filtered | SG-XNet | 1 | 35.1 ± 2.5 | +0.9 (3/5) | -8.2 (1/5) | - |
| squirrel_filtered→chameleon_filtered | SG-XNet | 5 | 35.9 ± 1.8 | -0.9 (3/5) | -5.7* (0/5) | - |
| squirrel_filtered→chameleon_filtered | SG-XNet | 20 | 38.3 ± 1.7 | +0.2 (3/5) | -3.9 (0/5) | - |
| amazon_ratings→roman_empire | GCN | 1 | 14.3 ± 2.1 | -0.0 (2/5) | +0.7 (3/5) | - |
| amazon_ratings→roman_empire | GCN | 5 | 24.1 ± 2.0 | -0.2 (2/5) | -0.8 (2/5) | - |
| amazon_ratings→roman_empire | GCN | 20 | 30.3 ± 0.7 | +0.0 (2/5) | -0.9 (2/5) | - |
| amazon_ratings→roman_empire | GraphSAGE | 1 | 19.2 ± 4.5 | +1.9 (5/5) | -0.0 (2/5) | - |
| amazon_ratings→roman_empire | GraphSAGE | 5 | 44.2 ± 3.6 | -1.1 (1/5) | -12.1 (0/5) | - |
| amazon_ratings→roman_empire | GraphSAGE | 20 | 57.6 ± 1.1 | +0.6 (5/5) | -9.4* (0/5) | - |
| amazon_ratings→roman_empire | GAT | 1 | 14.3 ± 1.0 | -0.5 (2/5) | -0.2 (2/5) | - |
| amazon_ratings→roman_empire | GAT | 5 | 20.1 ± 2.8 | +1.5 (4/5) | +2.3 (3/5) | - |
| amazon_ratings→roman_empire | GAT | 20 | 25.2 ± 2.4 | +0.4 (2/5) | +0.4 (3/5) | - |
| amazon_ratings→roman_empire | GIN | 1 | 14.3 ± 1.5 | +0.8 (4/5) | +0.7 (3/5) | - |
| amazon_ratings→roman_empire | GIN | 5 | 25.9 ± 4.0 | -0.7 (2/5) | +5.7* (5/5) | - |
| amazon_ratings→roman_empire | GIN | 20 | 44.2 ± 2.2 | +0.2 (3/5) | +3.2 (5/5) | - |
| amazon_ratings→roman_empire | MLP | 1 | 28.2 ± 3.8 | -0.5 (1/5) | -3.5 (1/5) | - |
| amazon_ratings→roman_empire | MLP | 5 | 38.3 ± 2.0 | +0.2 (2/5) | -0.6 (1/5) | - |
| amazon_ratings→roman_empire | MLP | 20 | 46.7 ± 1.5 | +0.1 (3/5) | -0.2 (1/5) | - |
| amazon_ratings→roman_empire | SG-XNet | 1 | 14.2 ± 2.1 | -0.3 (0/5) | -0.1 (2/5) | - |
| amazon_ratings→roman_empire | SG-XNet | 5 | 23.3 ± 2.9 | -0.4 (1/5) | -0.8 (2/5) | - |
| amazon_ratings→roman_empire | SG-XNet | 20 | 31.6 ± 1.0 | -0.2 (2/5) | -1.3 (0/5) | - |
| citeseer→chameleon_filtered | GCN | 1 | 34.8 ± 2.0 | -1.6* (0/5) | -0.9 (2/5) | - |
| citeseer→chameleon_filtered | GCN | 5 | 36.2 ± 1.6 | -1.3 (0/5) | -2.4 (0/5) | - |
| citeseer→chameleon_filtered | GCN | 20 | 36.7 ± 2.7 | -1.4 (1/5) | +0.1 (2/5) | - |
| citeseer→chameleon_filtered | GraphSAGE | 1 | 35.8 ± 2.6 | -4.3 (1/5) | -1.6 (2/5) | - |
| citeseer→chameleon_filtered | GraphSAGE | 5 | 34.2 ± 3.2 | +0.2 (3/5) | -0.1 (2/5) | - |
| citeseer→chameleon_filtered | GraphSAGE | 20 | 37.0 ± 3.3 | -0.4 (2/5) | -1.2 (2/5) | - |
| citeseer→chameleon_filtered | GAT | 1 | 35.8 ± 1.7 | -3.3 (1/5) | -5.3 (2/5) | - |
| citeseer→chameleon_filtered | GAT | 5 | 35.2 ± 2.2 | -6.7 (2/5) | -4.5 (1/5) | - |
| citeseer→chameleon_filtered | GAT | 20 | 37.0 ± 0.6 | -8.9 (2/5) | -5.5 (1/5) | - |
| citeseer→chameleon_filtered | GIN | 1 | 33.4 ± 3.1 | -0.8 (2/5) | -1.7 (2/5) | - |
| citeseer→chameleon_filtered | GIN | 5 | 35.0 ± 1.8 | -1.8 (0/5) | -1.4 (0/5) | - |
| citeseer→chameleon_filtered | GIN | 20 | 36.8 ± 2.4 | -0.0 (3/5) | -1.5 (1/5) | - |
| citeseer→chameleon_filtered | MLP | 1 | 28.3 ± 9.3 | +1.4 (3/5) | -0.9 (1/5) | - |
| citeseer→chameleon_filtered | MLP | 5 | 35.2 ± 1.5 | -3.0 (0/5) | -3.6 (0/5) | - |
| citeseer→chameleon_filtered | MLP | 20 | 38.5 ± 2.7 | -5.3 (0/5) | -5.9* (0/5) | - |
| citeseer→chameleon_filtered | SG-XNet | 1 | 35.1 ± 2.5 | +1.4 (3/5) | -9.5 (0/5) | - |
| citeseer→chameleon_filtered | SG-XNet | 5 | 35.9 ± 1.8 | +0.7 (3/5) | -5.3 (0/5) | - |
| citeseer→chameleon_filtered | SG-XNet | 20 | 38.3 ± 1.7 | +0.3 (3/5) | -4.2 (0/5) | - |

## 3. SG-XNet minus baseline (percentage points, paired by split)

Cell: SG-XNet minus baseline (* = paired t-test, Holm-adjusted within each baseline, p < 0.05). Full statistics: sgx_vs_baselines_pilot.csv.

| target | k | condition | SG-XNet | GCN | GraphSAGE | GAT | GIN | MLP |
|---|---|---|---|---|---|---|---|---|
| cora | 1 | scratch | 47.3 ± 10.9 | -6.2 | +0.1 | +0.8 | -1.9 | +20.2 |
| cora | 1 | finetune@citeseer | 47.2 ± 7.3 | -2.5 | +6.4 | -2.1 | +4.4 | +19.0 |
| cora | 5 | scratch | 69.3 ± 3.5 | -0.1 | +3.5 | -1.6 | -0.7 | +30.9* |
| cora | 5 | finetune@citeseer | 65.6 ± 7.0 | -3.0 | +6.9 | -2.1 | +1.1 | +28.2* |
| cora | 20 | scratch | 79.1 ± 1.5 | +0.9 | +2.2 | +1.1 | +1.2 | +23.5* |
| cora | 20 | finetune@citeseer | 75.6 ± 4.4 | -1.9 | +0.6 | -2.7 | +1.1 | +21.3* |
| pubmed | 1 | scratch | 55.0 ± 3.6 | -5.1 | +1.1 | -1.6 | -3.0 | +4.4* |
| pubmed | 1 | finetune@dblp | 54.1 ± 3.9 | -5.5 | -1.9 | -2.7 | -2.4 | +4.1 |
| pubmed | 5 | scratch | 66.2 ± 5.0 | -3.8 | -0.8 | -1.6 | +0.1 | +6.5 |
| pubmed | 5 | finetune@dblp | 65.3 ± 5.5 | -2.8 | -1.8 | -0.5 | -1.8 | +5.6 |
| pubmed | 20 | scratch | 74.0 ± 1.7 | -0.6 | -0.5 | -1.9 | -0.4 | +5.5* |
| pubmed | 20 | finetune@dblp | 74.5 ± 1.2 | -2.5* | +1.3 | -1.5 | -1.5 | +7.4* |
| dblpv7 | 1 | scratch | 31.6 ± 7.0 | -4.7 | -2.8 | +1.4 | -5.2 | +8.7 |
| dblpv7 | 1 | finetune@acmv9 | 67.1 ± 1.5 | -2.3 | +6.3 | +13.2* | -0.4 | +12.2* |
| dblpv7 | 1 | finetune@citationv1 | 69.8 ± 1.9 | -1.9 | +10.3 | +3.4 | +0.1 | +12.2* |
| dblpv7 | 5 | scratch | 53.4 ± 3.0 | -5.0 | +6.0 | +0.7 | +1.7 | +26.5* |
| dblpv7 | 5 | finetune@acmv9 | 70.3 ± 1.2 | +1.4 | +5.2 | +14.3 | +3.9 | +14.9* |
| dblpv7 | 5 | finetune@citationv1 | 69.4 ± 3.6 | -2.4 | +5.5 | +4.2 | -0.1 | +12.8* |
| dblpv7 | 20 | scratch | 65.7 ± 1.9 | -4.3 | +3.8 | -1.0 | -1.7 | +25.1* |
| dblpv7 | 20 | finetune@acmv9 | 71.7 ± 0.6 | -0.4 | +1.0 | +8.6 | +4.6 | +15.5* |
| dblpv7 | 20 | finetune@citationv1 | 73.3 ± 0.9 | -0.6 | +3.1 | +11.4* | +1.0 | +16.8* |
| citationv1 | 1 | scratch | 42.5 ± 6.5 | -6.4 | +10.8 | +0.7 | -0.3 | +15.3 |
| citationv1 | 1 | finetune@acmv9 | 73.2 ± 2.5 | +5.1 | +21.6 | +7.2 | +12.5 | +18.8* |
| citationv1 | 1 | finetune@dblpv7 | 74.7 ± 1.8 | +13.5 | +27.8 | +8.1 | +13.4 | +22.7* |
| citationv1 | 5 | scratch | 60.0 ± 5.1 | -5.6 | +5.5 | -1.5 | -1.4 | +29.3* |
| citationv1 | 5 | finetune@acmv9 | 75.0 ± 1.5 | -0.1 | +14.5 | +4.3 | +6.1 | +21.2* |
| citationv1 | 5 | finetune@dblpv7 | 73.0 ± 1.8 | -0.2 | +11.1 | +2.6 | +2.7 | +21.0* |
| citationv1 | 20 | scratch | 74.8 ± 1.6 | +0.1 | +5.4 | +2.8 | +3.0 | +39.4* |
| citationv1 | 20 | finetune@acmv9 | 77.3 ± 2.1 | -0.7 | +6.1 | +7.0* | +3.7 | +23.8* |
| citationv1 | 20 | finetune@dblpv7 | 77.0 ± 1.8 | -0.1 | +5.7 | +6.9 | +2.9 | +25.1* |
| acmv9 | 1 | scratch | 37.0 ± 6.8 | -2.2 | +2.5 | -2.2 | -2.4 | +9.0 |
| acmv9 | 1 | finetune@citationv1 | 68.1 ± 2.6 | +0.6 | +4.6 | +3.8 | +12.8 | +12.8* |
| acmv9 | 1 | finetune@dblpv7 | 65.9 ± 3.1 | +1.8 | +11.0 | +2.1 | +6.2 | +13.0* |
| acmv9 | 5 | scratch | 51.2 ± 2.9 | -0.9 | +6.2 | -0.5 | -3.6 | +19.8* |
| acmv9 | 5 | finetune@citationv1 | 68.8 ± 4.8 | +2.7 | +4.4 | +2.7 | +8.4 | +12.8* |
| acmv9 | 5 | finetune@dblpv7 | 65.1 ± 3.6 | +3.1 | +6.9 | +3.6 | +2.3 | +11.9* |
| acmv9 | 20 | scratch | 63.1 ± 3.2 | -4.2 | +2.5 | -2.6 | -1.1 | +24.1* |
| acmv9 | 20 | finetune@citationv1 | 71.8 ± 1.6 | +6.6 | +2.6 | +7.0* | +1.1 | +16.2* |
| acmv9 | 20 | finetune@dblpv7 | 69.6 ± 1.4 | +1.4 | +2.4 | +4.0 | +3.6 | +17.5* |
| chameleon_filtered | 1 | scratch | 35.1 ± 2.5 | +0.3 | -0.7 | -0.7 | +1.7 | +6.8 |
| chameleon_filtered | 1 | finetune@squirrel_filtered | 36.0 ± 3.0 | +0.2 | +3.4 | +1.3 | +2.4 | +2.3 |
| chameleon_filtered | 1 | finetune@citeseer | 36.4 ± 1.2 | +3.2 | +4.9 | +4.0 | +3.9 | +6.8 |
| chameleon_filtered | 5 | scratch | 35.9 ± 1.8 | -0.3 | +1.7 | +0.7 | +0.9 | +0.8 |
| chameleon_filtered | 5 | finetune@squirrel_filtered | 35.1 ± 3.4 | -0.5 | +1.9 | +0.4 | +0.3 | +0.4 |
| chameleon_filtered | 5 | finetune@citeseer | 36.6 ± 1.7 | +1.7 | +2.2 | +8.1 | +3.4 | +4.5 |
| chameleon_filtered | 20 | scratch | 38.3 ± 1.7 | +1.6 | +1.3 | +1.3 | +1.6 | -0.1 |
| chameleon_filtered | 20 | finetune@squirrel_filtered | 38.6 ± 1.9 | +0.7 | +0.7 | +2.7 | +0.2 | +2.4 |
| chameleon_filtered | 20 | finetune@citeseer | 38.6 ± 2.6 | +3.3 | +2.0 | +10.5 | +1.9 | +5.4 |
| roman_empire | 1 | scratch | 14.2 ± 2.1 | -0.2 | -5.0 | -0.1 | -0.1 | -14.0* |
| roman_empire | 1 | finetune@amazon_ratings | 13.8 ± 2.0 | -0.5 | -7.3 | +0.1 | -1.3 | -13.8* |
| roman_empire | 5 | scratch | 23.3 ± 2.9 | -0.8 | -20.9* | +3.2 | -2.6 | -15.0* |
| roman_empire | 5 | finetune@amazon_ratings | 22.9 ± 2.2 | -0.9 | -20.2* | +1.3 | -2.3 | -15.7* |
| roman_empire | 20 | scratch | 31.6 ± 1.0 | +1.2 | -26.0* | +6.3 | -12.7* | -15.1* |
| roman_empire | 20 | finetune@amazon_ratings | 31.3 ± 0.9 | +1.0 | -26.9* | +5.7 | -13.1* | -15.4* |

## 4. Public splits (Planetoid public split x 10 seeds; Platonov et al. 10 splits)

| dataset | GCN | GraphSAGE | GAT | GIN | MLP | SG-XNet |
|---|---|---|---|---|---|---|
| roman_empire | 63.3 ± 0.4 | **87.8 ± 0.5** | 64.3 ± 1.7 | 82.2 ± 0.8 | 66.5 ± 0.5 | 73.6 ± 0.5 |
| chameleon_filtered | 38.9 ± 3.8 | **41.8 ± 4.5** | 40.4 ± 3.8 | 41.6 ± 2.9 | 38.8 ± 2.8 | 40.8 ± 3.3 |
| amazon_ratings | 47.2 ± 0.7 | **53.7 ± 0.5** | 49.2 ± 0.6 | 50.1 ± 1.0 | 46.0 ± 0.7 | 49.6 ± 0.7 |
| citeseer | 68.9 ± 1.8 | 68.0 ± 1.3 | **70.5 ± 1.2** | 65.4 ± 1.3 | 59.6 ± 1.0 | 67.5 ± 1.0 |
| squirrel_filtered | 40.8 ± 1.9 | **43.3 ± 2.3** | 36.7 ± 3.2 | 40.8 ± 2.2 | 38.1 ± 2.2 | 40.3 ± 2.0 |
| cora | **81.4 ± 0.6** | 80.5 ± 0.6 | 81.1 ± 1.1 | 80.3 ± 1.1 | 60.0 ± 2.2 | 81.0 ± 0.4 |
| pubmed | **78.2 ± 1.2** | 77.8 ± 0.5 | 78.1 ± 0.5 | 76.6 ± 0.9 | 73.0 ± 0.5 | 78.2 ± 0.5 |
